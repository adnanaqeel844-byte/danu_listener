Check https://termux.dev/security for info on Termux security policies and how to report vulnerabilities.
